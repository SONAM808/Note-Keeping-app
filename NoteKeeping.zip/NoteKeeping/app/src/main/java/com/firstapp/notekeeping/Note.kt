package com.firstapp.notekeeping

data class Note(
    val title: String,
    val contents: String)
